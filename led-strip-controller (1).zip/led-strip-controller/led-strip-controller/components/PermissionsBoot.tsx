import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Linking,
  Platform,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import {
  PermissionsState,
  requestAllPermissions,
} from "@/lib/permissions";
import { PrimaryButton } from "./PrimaryButton";

type Props = { onReady: () => void };

export function PermissionsBoot({ onReady }: Props) {
  const colors = useColors();
  const [state, setState] = useState<PermissionsState | null>(null);
  const [working, setWorking] = useState(true);

  useEffect(() => {
    void run();
  }, []);

  async function run() {
    setWorking(true);
    const s = await requestAllPermissions();
    setState(s);
    setWorking(false);
    const requiredOk =
      s.bluetooth === "granted" &&
      (Platform.OS !== "android" || s.location === "granted");
    if (requiredOk) {
      // small delay so user sees confirmation
      setTimeout(onReady, 350);
    }
  }

  if (!state) {
    return (
      <View style={[styles.full, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={[styles.title, { color: colors.foreground, marginTop: 16 }]}>
          Setting things up
        </Text>
      </View>
    );
  }

  const items: { key: keyof PermissionsState; label: string; icon: keyof typeof Feather.glyphMap; required: boolean }[] = [
    { key: "bluetooth", label: "Bluetooth", icon: "bluetooth", required: true },
    { key: "location", label: "Location (required by Android for BLE)", icon: "map-pin", required: Platform.OS === "android" },
    { key: "microphone", label: "Microphone (voice + music vibe)", icon: "mic", required: false },
    { key: "speech", label: "Speech recognition", icon: "message-circle", required: false },
  ];

  const requiredMissing = items.some(
    (it) => it.required && state[it.key] !== "granted",
  );

  return (
    <View style={[styles.full, { backgroundColor: colors.background }]}>
      <View style={{ alignItems: "center", marginBottom: 24 }}>
        <Feather name="zap" size={36} color={colors.primary} />
        <Text style={[styles.title, { color: colors.foreground, marginTop: 12 }]}>
          Permissions
        </Text>
        <Text style={[styles.sub, { color: colors.mutedForeground }]}>
          The app needs these to talk to your LED strips and listen for voice commands.
        </Text>
      </View>

      <View style={{ width: "100%", gap: 10 }}>
        {items.map((it) => {
          const status = state[it.key];
          const ok = status === "granted";
          return (
            <View
              key={it.key}
              style={[
                styles.row,
                { backgroundColor: colors.card, borderColor: colors.border },
              ]}
            >
              <Feather name={it.icon} size={20} color={colors.foreground} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.rowTitle, { color: colors.foreground }]}>
                  {it.label}
                </Text>
                <Text
                  style={[
                    styles.rowSub,
                    {
                      color: ok
                        ? colors.accent
                        : it.required
                          ? colors.destructive
                          : colors.mutedForeground,
                    },
                  ]}
                >
                  {ok ? "Granted" : it.required ? "Required — denied" : "Optional — denied"}
                </Text>
              </View>
              <Feather
                name={ok ? "check-circle" : "x-circle"}
                size={22}
                color={ok ? colors.accent : colors.destructive}
              />
            </View>
          );
        })}
      </View>

      <View style={{ marginTop: 28, gap: 10, width: "100%" }}>
        <PrimaryButton
          fullWidth
          label={requiredMissing ? "Try again" : "Continue"}
          icon={requiredMissing ? "refresh-cw" : "arrow-right"}
          loading={working}
          onPress={requiredMissing ? run : onReady}
        />
        {requiredMissing ? (
          <PrimaryButton
            fullWidth
            variant="ghost"
            label="Open app settings"
            icon="settings"
            onPress={() => Linking.openSettings()}
          />
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  full: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 80,
    paddingBottom: 40,
    alignItems: "center",
  },
  title: { fontFamily: "Inter_700Bold", fontSize: 22 },
  sub: { fontFamily: "Inter_400Regular", fontSize: 14, textAlign: "center", marginTop: 8 },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
  },
  rowTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  rowSub: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
});
