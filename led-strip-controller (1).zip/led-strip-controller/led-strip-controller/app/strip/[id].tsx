import React, { useMemo, useState } from "react";
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useLocalSearchParams, useNavigation, useRouter } from "expo-router";
import ColorPicker from "react-native-wheel-color-picker";

import { useColors } from "@/hooks/useColors";
import { useApp } from "@/contexts/AppContext";
import { Slider } from "@/components/Slider";
import { PrimaryButton } from "@/components/PrimaryButton";
import type { RGB, Scene } from "@/lib/types";
import { disconnect } from "@/lib/ble";

const SCENES: { key: Scene; label: string; icon: keyof typeof Feather.glyphMap }[] = [
  { key: "rainbow", label: "Rainbow", icon: "sun" },
  { key: "warm", label: "Warm", icon: "coffee" },
  { key: "cool", label: "Cool", icon: "wind" },
  { key: "party", label: "Party", icon: "music" },
  { key: "calm", label: "Calm", icon: "feather" },
  { key: "fire", label: "Fire", icon: "thermometer" },
  { key: "ocean", label: "Ocean", icon: "droplet" },
];

export default function StripScreen() {
  const colors = useColors();
  const router = useRouter();
  const navigation = useNavigation();
  const { id: rawId } = useLocalSearchParams<{ id: string }>();
  const id = decodeURIComponent(rawId ?? "");
  const {
    devices,
    controlPower,
    controlColor,
    controlBrightness,
    controlScene,
    musicMode,
    startMusicMode,
    stopMusicMode,
    renameDevice,
    removeDevice,
  } = useApp();

  const device = devices.find((d) => d.id === id);
  const [editingName, setEditingName] = useState(false);
  const [name, setName] = useState(device?.name ?? "");
  const [tempColor, setTempColor] = useState<RGB>(device?.color ?? { r: 255, g: 255, b: 255 });

  const target = useMemo(() => ({ kind: "device" as const, id }), [id]);
  const musicActive = musicMode.active && musicMode.target?.kind === "device" && musicMode.target.id === id;

  React.useEffect(() => {
    if (device) navigation.setOptions({ title: device.name });
  }, [navigation, device]);

  if (!device) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, alignItems: "center", justifyContent: "center" }]}>
        <Feather name="alert-circle" size={36} color={colors.mutedForeground} />
        <Text style={{ color: colors.foreground, marginTop: 12, fontFamily: "Inter_600SemiBold" }}>
          Light not found
        </Text>
        <PrimaryButton style={{ marginTop: 16 }} label="Go back" icon="arrow-left" onPress={() => router.back()} />
      </View>
    );
  }

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={styles.scroll}
      keyboardShouldPersistTaps="handled"
    >
      {/* Name + power */}
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <View
            style={[
              styles.glow,
              {
                backgroundColor: device.isOn
                  ? `rgb(${device.color.r},${device.color.g},${device.color.b})`
                  : colors.muted,
                shadowColor: device.isOn
                  ? `rgb(${device.color.r},${device.color.g},${device.color.b})`
                  : "transparent",
              },
            ]}
          />
          {editingName ? (
            <TextInput
              value={name}
              onChangeText={setName}
              autoFocus
              onBlur={() => {
                setEditingName(false);
                if (name.trim()) renameDevice(device.id, name.trim());
              }}
              style={[styles.nameInput, { color: colors.foreground, borderColor: colors.border }]}
            />
          ) : (
            <Pressable onPress={() => setEditingName(true)} style={{ flex: 1 }}>
              <Text style={[styles.name, { color: colors.foreground }]}>{device.name}</Text>
              <Text style={[styles.nameSub, { color: colors.mutedForeground }]}>
                Tap to rename
              </Text>
            </Pressable>
          )}
          <Pressable
            onPress={() => controlPower(target, !device.isOn)}
            style={[
              styles.power,
              { backgroundColor: device.isOn ? colors.primary : colors.secondary, borderColor: colors.border },
            ]}
          >
            <Feather
              name="power"
              size={20}
              color={device.isOn ? colors.primaryForeground : colors.mutedForeground}
            />
          </Pressable>
        </View>
      </View>

      {/* Color */}
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>Color</Text>
        <View style={styles.wheel}>
          <ColorPicker
            color={`rgb(${tempColor.r}, ${tempColor.g}, ${tempColor.b})`}
            onColorChange={(hex: string) => {
              const rgb = hexToRgb(hex);
              if (rgb) setTempColor(rgb);
            }}
            onColorChangeComplete={(hex: string) => {
              const rgb = hexToRgb(hex);
              if (rgb) {
                setTempColor(rgb);
                void controlColor(target, rgb);
              }
            }}
            thumbSize={28}
            sliderSize={28}
            noSnap
            row={false}
            swatches={false}
          />
        </View>
        <View style={styles.swatches}>
          {[
            { r: 255, g: 255, b: 255 },
            { r: 255, g: 80, b: 80 },
            { r: 255, g: 170, b: 60 },
            { r: 255, g: 230, b: 80 },
            { r: 80, g: 220, b: 120 },
            { r: 60, g: 160, b: 255 },
            { r: 168, g: 85, b: 247 },
            { r: 255, g: 60, b: 200 },
          ].map((c, i) => (
            <Pressable
              key={i}
              onPress={() => {
                setTempColor(c);
                void controlColor(target, c);
              }}
              style={[
                styles.swatch,
                {
                  backgroundColor: `rgb(${c.r},${c.g},${c.b})`,
                  borderColor: colors.border,
                },
              ]}
            />
          ))}
        </View>
      </View>

      {/* Brightness */}
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Text style={[styles.cardTitle, { color: colors.foreground, flex: 1 }]}>Brightness</Text>
          <Text style={[styles.cardSub, { color: colors.mutedForeground }]}>
            {device.brightness}%
          </Text>
        </View>
        <Slider
          value={device.brightness}
          onChange={(v) => {
            // optimistic local feedback only, commit on release
          }}
          onCommit={(v) => controlBrightness(target, v)}
          fillColor={`rgb(${device.color.r},${device.color.g},${device.color.b})`}
        />
      </View>

      {/* Scenes */}
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>Scenes</Text>
        <View style={styles.sceneGrid}>
          {SCENES.map((s) => (
            <Pressable
              key={s.key}
              onPress={() => controlScene(target, s.key)}
              style={[styles.sceneBtn, { backgroundColor: colors.secondary, borderColor: colors.border }]}
            >
              <Feather name={s.icon} size={20} color={colors.primary} />
              <Text style={[styles.sceneText, { color: colors.foreground }]}>{s.label}</Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* Music vibe */}
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>Music vibe</Text>
        <Text style={[styles.cardSub, { color: colors.mutedForeground }]}>
          Listens to your microphone and pulses the light to the beat.
        </Text>
        <PrimaryButton
          fullWidth
          icon={musicActive ? "square" : "music"}
          label={musicActive ? "Stop music vibe" : "Start music vibe"}
          variant={musicActive ? "danger" : "primary"}
          onPress={() => (musicActive ? stopMusicMode() : startMusicMode(target))}
        />
      </View>

      {/* Danger zone */}
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <PrimaryButton
          fullWidth
          variant="ghost"
          icon="link"
          label="Disconnect"
          onPress={async () => {
            await disconnect(device.id);
            Alert.alert("Disconnected", `${device.name} has been disconnected.`);
          }}
        />
        <PrimaryButton
          fullWidth
          variant="danger"
          icon="trash-2"
          label="Forget light"
          style={{ marginTop: 8 }}
          onPress={() =>
            Alert.alert("Forget this light?", device.name, [
              { text: "Cancel", style: "cancel" },
              {
                text: "Forget",
                style: "destructive",
                onPress: async () => {
                  await disconnect(device.id);
                  await removeDevice(device.id);
                  router.back();
                },
              },
            ])
          }
        />
      </View>
    </ScrollView>
  );
}

function hexToRgb(hex: string): RGB | null {
  if (hex.startsWith("rgb")) {
    const m = hex.match(/(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
    if (!m) return null;
    return { r: +m[1]!, g: +m[2]!, b: +m[3]! };
  }
  const v = hex.replace("#", "");
  if (v.length !== 6) return null;
  return {
    r: parseInt(v.slice(0, 2), 16),
    g: parseInt(v.slice(2, 4), 16),
    b: parseInt(v.slice(4, 6), 16),
  };
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { padding: 16, paddingBottom: 60, gap: 14 },
  card: { padding: 16, borderRadius: 18, borderWidth: 1, gap: 12 },
  cardTitle: { fontFamily: "Inter_700Bold", fontSize: 16 },
  cardSub: { fontFamily: "Inter_400Regular", fontSize: 13 },
  glow: {
    width: 28,
    height: 28,
    borderRadius: 14,
    shadowOpacity: 0.9,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 0 },
  },
  name: { fontFamily: "Inter_700Bold", fontSize: 18 },
  nameSub: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
  nameInput: {
    flex: 1,
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    borderBottomWidth: 1,
    paddingVertical: 4,
  },
  power: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
  },
  wheel: { height: 280, alignItems: "center", justifyContent: "center" },
  swatches: { flexDirection: "row", flexWrap: "wrap", gap: 10, justifyContent: "center" },
  swatch: { width: 36, height: 36, borderRadius: 18, borderWidth: 1 },
  sceneGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  sceneBtn: {
    minWidth: 96,
    flexBasis: "30%",
    flexGrow: 1,
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    gap: 6,
  },
  sceneText: { fontFamily: "Inter_500Medium", fontSize: 13 },
});
