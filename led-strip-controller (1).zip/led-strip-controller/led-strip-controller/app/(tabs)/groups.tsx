import React, { useMemo, useState } from "react";
import {
  FlatList,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";

import { useColors } from "@/hooks/useColors";
import { useApp } from "@/contexts/AppContext";
import { PrimaryButton } from "@/components/PrimaryButton";

export default function GroupsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { groups, devices, createGroup, removeGroup } = useApp();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const canCreate = name.trim().length > 0 && selected.size > 0;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={groups}
        keyExtractor={(g) => g.id}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <View style={{ paddingBottom: 12 }}>
            <PrimaryButton
              fullWidth
              icon="plus"
              label="Create group"
              onPress={() => {
                setName("");
                setSelected(new Set());
                setOpen(true);
              }}
            />
          </View>
        }
        renderItem={({ item }) => {
          const groupDevices = devices.filter((d) => item.deviceIds.includes(d.id));
          return (
            <Pressable
              onPress={() => router.push(`/group/${encodeURIComponent(item.id)}`)}
              style={({ pressed }) => [
                styles.card,
                { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.85 : 1 },
              ]}
            >
              <View style={{ flex: 1 }}>
                <Text style={[styles.cardTitle, { color: colors.foreground }]}>
                  {item.name}
                </Text>
                <Text style={[styles.cardSub, { color: colors.mutedForeground }]}>
                  {groupDevices.length} {groupDevices.length === 1 ? "light" : "lights"}
                </Text>
              </View>
              <Pressable
                onPress={() => removeGroup(item.id)}
                hitSlop={10}
                style={styles.iconBtn}
              >
                <Feather name="trash-2" size={18} color={colors.mutedForeground} />
              </Pressable>
              <Feather name="chevron-right" size={22} color={colors.mutedForeground} />
            </Pressable>
          );
        }}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="layers" size={36} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              No groups yet
            </Text>
            <Text style={[styles.emptySub, { color: colors.mutedForeground }]}>
              Group lights together so a single voice command (or button) controls all of them.
            </Text>
          </View>
        }
      />

      <Modal animationType="slide" visible={open} onRequestClose={() => setOpen(false)} transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.modal, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>New group</Text>
              <Pressable onPress={() => setOpen(false)} hitSlop={10}>
                <Feather name="x" size={22} color={colors.mutedForeground} />
              </Pressable>
            </View>
            <TextInput
              value={name}
              onChangeText={setName}
              placeholder="Group name (e.g. Bedroom)"
              placeholderTextColor={colors.mutedForeground}
              style={[
                styles.input,
                { backgroundColor: colors.input, color: colors.foreground, borderColor: colors.border },
              ]}
            />
            <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>
              Select lights
            </Text>
            <View style={{ maxHeight: 280 }}>
              <FlatList
                data={devices}
                keyExtractor={(d) => d.id}
                renderItem={({ item }) => {
                  const checked = selected.has(item.id);
                  return (
                    <Pressable
                      onPress={() => {
                        const next = new Set(selected);
                        if (checked) next.delete(item.id);
                        else next.add(item.id);
                        setSelected(next);
                      }}
                      style={[styles.deviceRow, { borderColor: colors.border }]}
                    >
                      <Feather
                        name={checked ? "check-square" : "square"}
                        size={20}
                        color={checked ? colors.primary : colors.mutedForeground}
                      />
                      <Text style={[styles.deviceText, { color: colors.foreground }]}>
                        {item.name}
                      </Text>
                    </Pressable>
                  );
                }}
                ListEmptyComponent={
                  <Text style={[styles.emptySub, { color: colors.mutedForeground }]}>
                    Pair some lights first.
                  </Text>
                }
              />
            </View>
            <PrimaryButton
              fullWidth
              icon="check"
              label="Create"
              disabled={!canCreate}
              onPress={async () => {
                await createGroup(name.trim(), Array.from(selected));
                setOpen(false);
              }}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  listContent: { padding: 16, paddingBottom: 120 },
  card: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderRadius: 18,
    borderWidth: 1,
    gap: 8,
  },
  cardTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16 },
  cardSub: { fontFamily: "Inter_400Regular", fontSize: 13, marginTop: 2 },
  iconBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  empty: { alignItems: "center", paddingVertical: 60, paddingHorizontal: 24, gap: 8 },
  emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16, marginTop: 12 },
  emptySub: { fontFamily: "Inter_400Regular", fontSize: 13, textAlign: "center" },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" },
  modal: {
    borderWidth: 1,
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    padding: 20,
    paddingBottom: 36,
    gap: 12,
  },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  modalTitle: { fontFamily: "Inter_700Bold", fontSize: 18 },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontFamily: "Inter_500Medium",
    fontSize: 15,
  },
  sectionLabel: { fontFamily: "Inter_500Medium", fontSize: 12, textTransform: "uppercase", letterSpacing: 1 },
  deviceRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  deviceText: { fontFamily: "Inter_500Medium", fontSize: 14 },
});
