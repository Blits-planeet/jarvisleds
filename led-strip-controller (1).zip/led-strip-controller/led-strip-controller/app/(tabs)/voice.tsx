import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import * as Speech from "expo-speech";

import { useColors } from "@/hooks/useColors";
import { useApp } from "@/contexts/AppContext";
import { PrimaryButton } from "@/components/PrimaryButton";
import { askAi } from "@/lib/ai";
import {
  ExpoSpeechRecognitionModule,
  startListening,
  stopListening,
  useSpeechRecognitionEvent,
} from "@/lib/voice";

export default function VoiceScreen() {
  const colors = useColors();
  const router = useRouter();
  const { commands, removeCommand, upsertCommand, matchAndExecute, settings, updateSettings } = useApp();

  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState("");
  const [final, setFinal] = useState("");
  const [lastResult, setLastResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [aiAnswer, setAiAnswer] = useState<string | null>(null);
  const [aiThinking, setAiThinking] = useState(false);
  const [testText, setTestText] = useState("");

  function speak(text: string) {
    if (!settings.aiSpeakReplies) return;
    try {
      Speech.stop();
      Speech.speak(text, { rate: 1.0, pitch: 1.0 });
    } catch {
      /* ignore TTS failures */
    }
  }

  useSpeechRecognitionEvent("start", () => setListening(true));
  useSpeechRecognitionEvent("end", () => setListening(false));
  useSpeechRecognitionEvent("error", (e) => {
    setListening(false);
    setLastResult({ ok: false, message: `Recognition error: ${e.error}` });
  });
  useSpeechRecognitionEvent("result", (e) => {
    const t = e.results?.[0]?.transcript ?? "";
    if (e.isFinal) {
      setFinal(t);
      setInterim("");
      void runMatch(t);
    } else {
      setInterim(t);
    }
  });

  async function runMatch(transcript: string) {
    const t = transcript.trim();
    if (!t) return;
    setAiAnswer(null);
    const r = await matchAndExecute(t);
    if (r.cmd) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setLastResult({ ok: true, message: `Matched "${r.cmd.phrase}" — ${r.message}` });
      return;
    }
    // No LED command matched — fall through to AI Q&A
    Haptics.selectionAsync();
    setLastResult({ ok: true, message: `Asking AI: "${t}"` });
    askedQuestionRef.current = t;
    setAiThinking(true);
    try {
      const ai = await askAi(settings.aiServerUrl, t);
      if (ai.ok) {
        setAiAnswer(ai.answer);
        speak(ai.answer);
      } else {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        setLastResult({ ok: false, message: ai.error });
      }
    } finally {
      setAiThinking(false);
    }
  }

  async function startTap() {
    try {
      const status = await ExpoSpeechRecognitionModule.getPermissionsAsync();
      if (!status.granted) {
        const req = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
        if (!req.granted) {
          Alert.alert("Microphone needed", "Grant speech permission in app settings.");
          return;
        }
      }
      setFinal("");
      setInterim("");
      startListening({ continuous: false, interim: true });
    } catch (e) {
      setLastResult({ ok: false, message: String(e) });
    }
  }

  function stopTap() {
    stopListening();
  }

  // Continuous listening lifecycle
  useEffect(() => {
    if (!settings.continuousListening) return;
    let cancelled = false;
    const loop = () => {
      if (cancelled) return;
      try {
        startListening({ continuous: true, interim: true });
      } catch {
        /* ignore */
      }
    };
    loop();
    return () => {
      cancelled = true;
      stopListening();
    };
  }, [settings.continuousListening]);

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={styles.scroll}
      keyboardShouldPersistTaps="handled"
    >
      {/* Tester card */}
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>Voice tester</Text>
        <Text style={[styles.cardSub, { color: colors.mutedForeground }]}>
          Try a command by tapping the mic, or type one to dry-run.
        </Text>

        <Pressable
          onPress={listening ? stopTap : startTap}
          style={[
            styles.mic,
            {
              backgroundColor: listening ? colors.destructive : colors.primary,
              shadowColor: listening ? colors.destructive : colors.primary,
            },
          ]}
        >
          <Feather name={listening ? "square" : "mic"} size={36} color="#fff" />
        </Pressable>

        <Text style={[styles.transcript, { color: colors.foreground }]}>
          {final || interim || (listening ? "Listening…" : "Tap the mic and say a command")}
        </Text>

        {lastResult ? (
          <View
            style={[
              styles.result,
              {
                backgroundColor: lastResult.ok ? "rgba(34,211,238,0.1)" : "rgba(239,68,68,0.1)",
                borderColor: lastResult.ok ? colors.accent : colors.destructive,
              },
            ]}
          >
            <Feather
              name={lastResult.ok ? "check-circle" : "alert-circle"}
              size={16}
              color={lastResult.ok ? colors.accent : colors.destructive}
            />
            <Text style={[styles.resultText, { color: colors.foreground }]}>
              {lastResult.message}
            </Text>
          </View>
        ) : null}

        {aiThinking ? (
          <View
            style={[
              styles.result,
              {
                backgroundColor: "rgba(99,102,241,0.1)",
                borderColor: colors.primary,
              },
            ]}
          >
            <ActivityIndicator size="small" color={colors.primary} />
            <Text style={[styles.resultText, { color: colors.foreground }]}>
              Thinking…
            </Text>
          </View>
        ) : null}

        {aiAnswer ? (
          <View
            style={[
              styles.result,
              {
                backgroundColor: "rgba(99,102,241,0.1)",
                borderColor: colors.primary,
                alignItems: "flex-start",
              },
            ]}
          >
            <Feather name="message-circle" size={16} color={colors.primary} />
            <View style={{ flex: 1, gap: 6 }}>
              <Text style={[styles.resultText, { color: colors.foreground }]}>
                {aiAnswer}
              </Text>
              <Pressable
                onPress={() => speak(aiAnswer)}
                hitSlop={6}
                style={{ flexDirection: "row", alignItems: "center", gap: 6 }}
              >
                <Feather name="volume-2" size={14} color={colors.mutedForeground} />
                <Text style={[styles.cardSub, { color: colors.mutedForeground }]}>
                  Speak again
                </Text>
              </Pressable>
            </View>
          </View>
        ) : null}

        <View style={{ flexDirection: "row", gap: 8 }}>
          <TextInput
            value={testText}
            onChangeText={setTestText}
            placeholder='Type "turn lights off"'
            placeholderTextColor={colors.mutedForeground}
            style={[
              styles.input,
              { backgroundColor: colors.input, color: colors.foreground, borderColor: colors.border, flex: 1 },
            ]}
          />
          <PrimaryButton
            label="Run"
            icon="zap"
            variant="secondary"
            onPress={() => runMatch(testText)}
          />
        </View>
      </View>

      {/* Settings card */}
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>Settings</Text>
        <View style={styles.settingRow}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.settingTitle, { color: colors.foreground }]}>
              Continuous listening
            </Text>
            <Text style={[styles.settingSub, { color: colors.mutedForeground }]}>
              Keep mic open while the app is foregrounded.
            </Text>
          </View>
          <Switch
            value={settings.continuousListening}
            onValueChange={(v) => updateSettings({ continuousListening: v })}
            trackColor={{ false: colors.secondary, true: colors.primary }}
          />
        </View>
        <View style={styles.settingRow}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.settingTitle, { color: colors.foreground }]}>Hotword</Text>
            <Text style={[styles.settingSub, { color: colors.mutedForeground }]}>
              Optional prefix (e.g. "lights, turn off"). Leave commands unprefixed if you don't use one.
            </Text>
          </View>
        </View>
        <TextInput
          value={settings.hotword}
          onChangeText={(t) => updateSettings({ hotword: t })}
          placeholder="lights"
          placeholderTextColor={colors.mutedForeground}
          style={[
            styles.input,
            { backgroundColor: colors.input, color: colors.foreground, borderColor: colors.border },
          ]}
        />

        <View style={styles.settingRow}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.settingTitle, { color: colors.foreground }]}>
              AI assistant URL
            </Text>
            <Text style={[styles.settingSub, { color: colors.mutedForeground }]}>
              Where to send questions that aren't LED commands. Paste your deployed server URL (e.g. https://your-app.replit.app).
            </Text>
          </View>
        </View>
        <TextInput
          value={settings.aiServerUrl}
          onChangeText={(t) => updateSettings({ aiServerUrl: t })}
          placeholder="https://your-app.replit.app"
          placeholderTextColor={colors.mutedForeground}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="url"
          style={[
            styles.input,
            { backgroundColor: colors.input, color: colors.foreground, borderColor: colors.border },
          ]}
        />

        <View style={styles.settingRow}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.settingTitle, { color: colors.foreground }]}>
              Speak AI replies
            </Text>
            <Text style={[styles.settingSub, { color: colors.mutedForeground }]}>
              Read AI answers out loud using your phone's voice.
            </Text>
          </View>
          <Switch
            value={settings.aiSpeakReplies}
            onValueChange={(v) => updateSettings({ aiSpeakReplies: v })}
            trackColor={{ false: colors.secondary, true: colors.primary }}
          />
        </View>
      </View>

      {/* Commands list */}
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}>
          <Text style={[styles.cardTitle, { color: colors.foreground, flex: 1 }]}>
            Commands
          </Text>
          <Pressable
            onPress={() => router.push("/command/edit")}
            style={[styles.addBtn, { backgroundColor: colors.primary }]}
            hitSlop={6}
          >
            <Feather name="plus" size={18} color={colors.primaryForeground} />
          </Pressable>
        </View>
        {commands.length === 0 ? (
          <Text style={[styles.cardSub, { color: colors.mutedForeground }]}>
            No commands yet. Add one to control your lights with your voice.
          </Text>
        ) : (
          <FlatList
            data={commands}
            keyExtractor={(c) => c.id}
            scrollEnabled={false}
            ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
            renderItem={({ item }) => (
              <Pressable
                onPress={() => router.push(`/command/edit?id=${encodeURIComponent(item.id)}`)}
                style={[styles.cmdRow, { borderColor: colors.border }]}
              >
                <View style={{ flex: 1 }}>
                  <Text style={[styles.cmdPhrase, { color: colors.foreground }]} numberOfLines={1}>
                    "{item.phrase}"
                  </Text>
                  <Text style={[styles.cmdAction, { color: colors.mutedForeground }]} numberOfLines={1}>
                    {actionLabel(item)}
                  </Text>
                </View>
                <Switch
                  value={item.enabled}
                  onValueChange={(v) => upsertCommand({ ...item, enabled: v })}
                  trackColor={{ false: colors.secondary, true: colors.primary }}
                />
                <Pressable
                  onPress={() =>
                    Alert.alert("Delete command?", `"${item.phrase}"`, [
                      { text: "Cancel", style: "cancel" },
                      { text: "Delete", style: "destructive", onPress: () => removeCommand(item.id) },
                    ])
                  }
                  hitSlop={8}
                  style={{ padding: 8 }}
                >
                  <Feather name="trash-2" size={18} color={colors.mutedForeground} />
                </Pressable>
              </Pressable>
            )}
          />
        )}
      </View>
    </ScrollView>
  );
}

function actionLabel(c: ReturnType<typeof Object> | any): string {
  const targetLbl =
    c.target.kind === "all"
      ? "all"
      : c.target.kind === "device"
        ? "1 light"
        : "group";
  switch (c.action) {
    case "on":
      return `Turn ${targetLbl} on`;
    case "off":
      return `Turn ${targetLbl} off`;
    case "color":
      return c.color
        ? `Color (${c.color.r}, ${c.color.g}, ${c.color.b}) → ${targetLbl}`
        : `Color → ${targetLbl}`;
    case "brightness":
      return `Brightness ${c.brightness ?? "?"}% → ${targetLbl}`;
    case "scene":
      return `Scene ${c.scene} → ${targetLbl}`;
    case "music":
      return `Music vibe → ${targetLbl}`;
    default:
      return targetLbl;
  }
}

const styles = StyleSheet.create({
  scroll: { padding: 16, paddingBottom: 140, gap: 14 },
  card: {
    padding: 16,
    borderRadius: 18,
    borderWidth: 1,
    gap: 12,
  },
  cardTitle: { fontFamily: "Inter_700Bold", fontSize: 18 },
  cardSub: { fontFamily: "Inter_400Regular", fontSize: 13 },
  mic: {
    alignSelf: "center",
    width: 96,
    height: 96,
    borderRadius: 48,
    alignItems: "center",
    justifyContent: "center",
    shadowOpacity: 0.7,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 0 },
    elevation: 10,
  },
  transcript: {
    fontFamily: "Inter_500Medium",
    fontSize: 16,
    textAlign: "center",
    minHeight: 24,
  },
  result: {
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
    padding: 10,
    borderRadius: 10,
    borderWidth: 1,
  },
  resultText: { flex: 1, fontFamily: "Inter_500Medium", fontSize: 13 },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontFamily: "Inter_500Medium",
    fontSize: 15,
  },
  settingRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  settingTitle: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  settingSub: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
  addBtn: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  cmdRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
  },
  cmdPhrase: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  cmdAction: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
});
