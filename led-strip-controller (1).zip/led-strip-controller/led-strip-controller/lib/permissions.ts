import { Platform, PermissionsAndroid, Permission } from "react-native";
import * as Location from "expo-location";
import { ExpoSpeechRecognitionModule } from "expo-speech-recognition";
import { Audio } from "expo-av";

export type PermissionStatus = "granted" | "denied" | "unavailable";

export type PermissionsState = {
  bluetooth: PermissionStatus;
  location: PermissionStatus;
  microphone: PermissionStatus;
  speech: PermissionStatus;
};

export async function requestAllPermissions(): Promise<PermissionsState> {
  const state: PermissionsState = {
    bluetooth: "unavailable",
    location: "unavailable",
    microphone: "unavailable",
    speech: "unavailable",
  };

  // Bluetooth (Android 12+ uses runtime perms)
  if (Platform.OS === "android") {
    const apiLevel = Number(Platform.Version);
    const blePerms: Permission[] = [];
    if (apiLevel >= 31) {
      blePerms.push(
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
      );
    }
    blePerms.push(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);
    try {
      const result = await PermissionsAndroid.requestMultiple(blePerms);
      const allBleGranted =
        apiLevel < 31 ||
        (result[PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN] === "granted" &&
          result[PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT] === "granted");
      state.bluetooth = allBleGranted ? "granted" : "denied";
      state.location =
        result[PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION] === "granted"
          ? "granted"
          : "denied";
    } catch {
      state.bluetooth = "denied";
      state.location = "denied";
    }
  } else if (Platform.OS === "ios") {
    state.bluetooth = "granted";
    try {
      const loc = await Location.requestForegroundPermissionsAsync();
      state.location = loc.granted ? "granted" : "denied";
    } catch {
      state.location = "denied";
    }
  }

  // Microphone
  try {
    const mic = await Audio.requestPermissionsAsync();
    state.microphone = mic.granted ? "granted" : "denied";
  } catch {
    state.microphone = "denied";
  }

  // Speech recognition
  try {
    const sr = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
    state.speech = sr.granted ? "granted" : "denied";
  } catch {
    state.speech = "denied";
  }

  return state;
}
