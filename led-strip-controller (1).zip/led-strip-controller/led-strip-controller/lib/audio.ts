import { Audio } from "expo-av";

export type LevelListener = (level: number) => void;

let recording: Audio.Recording | null = null;
let listeners = new Set<LevelListener>();

export async function startMeter(): Promise<void> {
  if (recording) return;
  await Audio.setAudioModeAsync({
    allowsRecordingIOS: true,
    playsInSilentModeIOS: true,
  });
  const rec = new Audio.Recording();
  await rec.prepareToRecordAsync({
    ...Audio.RecordingOptionsPresets.LOW_QUALITY,
    isMeteringEnabled: true,
  });
  rec.setOnRecordingStatusUpdate((status) => {
    if (!status.isRecording) return;
    const db = status.metering ?? -160;
    // Map -60..0 dB to 0..1
    const norm = Math.max(0, Math.min(1, (db + 60) / 60));
    listeners.forEach((cb) => cb(norm));
  });
  rec.setProgressUpdateInterval(100);
  await rec.startAsync();
  recording = rec;
}

export async function stopMeter(): Promise<void> {
  const r = recording;
  recording = null;
  if (!r) return;
  try {
    await r.stopAndUnloadAsync();
  } catch {
    /* noop */
  }
}

export function subscribeLevel(cb: LevelListener): () => void {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}
