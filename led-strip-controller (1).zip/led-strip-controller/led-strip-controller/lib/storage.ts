import AsyncStorage from "@react-native-async-storage/async-storage";
import type { Device, Group, VoiceCommand } from "./types";

const KEYS = {
  devices: "@led/devices",
  groups: "@led/groups",
  commands: "@led/commands",
  settings: "@led/settings",
};

export type Settings = {
  hotword: string;
  continuousListening: boolean;
  musicSensitivity: number;
  aiServerUrl: string;
  aiSpeakReplies: boolean;
};

export const DEFAULT_SETTINGS: Settings = {
  hotword: "lights",
  continuousListening: false,
  musicSensitivity: 0.5,
  aiServerUrl: "",
  aiSpeakReplies: true,
};

async function readJson<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

async function writeJson<T>(key: string, value: T): Promise<void> {
  await AsyncStorage.setItem(key, JSON.stringify(value));
}

export const storage = {
  loadDevices: () => readJson<Device[]>(KEYS.devices, []),
  saveDevices: (d: Device[]) => writeJson(KEYS.devices, d),
  loadGroups: () => readJson<Group[]>(KEYS.groups, []),
  saveGroups: (g: Group[]) => writeJson(KEYS.groups, g),
  loadCommands: () => readJson<VoiceCommand[]>(KEYS.commands, []),
  saveCommands: (c: VoiceCommand[]) => writeJson(KEYS.commands, c),
  loadSettings: () => readJson<Settings>(KEYS.settings, DEFAULT_SETTINGS),
  saveSettings: (s: Settings) => writeJson(KEYS.settings, s),
};
